<?php
$page_title = '';
$page_css = ['shop.css'];
$body_class = 'shop-page';
include 'header.php';
?>

<section class="hero" aria-labelledby="hero-title">
    <div class="hero-body">
        <h1 id="hero-title" class="hero-title seq" style="--d:.05s"><?php echo e($slogan); ?></h1>
        <p class="hero-desc seq" style="--d:.2s">Oyunlar yapıyor, oyuncular için seçip getiriyoruz. Stüdyomuzda yeni evrenler kuruyor, mağazamızda dijital kütüphaneni büyütüyoruz.</p>
        <div class="hero-actions seq" style="--d:.35s">
            <a href="shop.php" class="btn btn-primary">Mağazaya gir</a>
            <a href="<?php echo e($studio_url); ?>" class="btn btn-ghost" target="_blank" rel="noopener">Stüdyoyu keşfet</a>
        </div>
    </div>
    <div class="hero-strip seq" style="--d:.55s">
        <a href="#nexus" class="strip-item"><span class="pulse" aria-hidden="true"></span><?php echo e($featured_project_name); ?> &middot; <?php echo e($featured_project_status); ?></a>
        <span class="strip-item strip-place"><?php echo e($city); ?></span>
    </div>
</section>
<?php include 'partials/slider.php'; ?>
    <br> <br>

<section class="ecosystem" aria-label="Stüdyo ve mağaza">
    <article class="pane pane-studio">
        <div class="pane-content">
            <h2>Stüdyo</h2>
            <p>Sınırları zorlayan hikayeler ve yeni nesil grafiklerle örülmüş evrenler inşa ediyoruz.</p>
            <a href="<?php echo e($studio_url); ?>" class="btn btn-primary" target="_blank" rel="noopener">Oyunları keşfet</a>
        </div>
    </article>
    <article class="pane pane-shop">
        <div class="pane-content">
            <h2>Mağaza</h2>
            <p>Seçilmiş oyun keyleri, premium hesaplar ve stüdyo imzalı ekipmanlar. Dijital kütüphaneni genişlet.</p>
            <a href="shop.php" class="btn btn-dark">Mağazaya gir</a>
        </div>
    </article>
</section>

<section class="shop-section" aria-labelledby="shop-picks-title">
    <div class="shop-section-head">
        <div>
            <p class="eyebrow">Mağazadan</p>
            <h2 id="shop-picks-title">Raflardan seçtiklerimiz.</h2>
        </div>
        <a href="shop.php" class="text-link">Tüm mağazayı gör</a>
    </div>
    <div class="p-grid">
        <?php foreach (array_slice(shop_products(), 0, 4) as $index => $product): ?>
            <?php include 'partials/product-card.php'; ?>
        <?php endforeach; ?>
    </div>
</section>

<section class="nexus" id="nexus" aria-labelledby="nexus-title">
    <div class="nexus-inner">
        <p class="status"><span class="pulse" aria-hidden="true"></span><?php echo e($featured_project_status); ?></p>
        <div class="nexus-main">
            <h2 id="nexus-title" class="nexus-title"><?php echo e($featured_project_name); ?></h2>
            <p class="nexus-desc"><?php echo e($featured_project_desc); ?></p>
            <a href="<?php echo e($studio_url); ?>" class="text-link" target="_blank" rel="noopener">Geliştirici günlüklerini oku</a>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>
